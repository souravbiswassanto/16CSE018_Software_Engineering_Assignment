package Implemented_Using_ChainPattern;
/*
 * Used HashMap, ArrayList, OOP
 * Used ChainOfResponsibility Pattern
 * Showed selected list of Subjects of a Candidate
 */
public class _Description_of_the_Code {

}
