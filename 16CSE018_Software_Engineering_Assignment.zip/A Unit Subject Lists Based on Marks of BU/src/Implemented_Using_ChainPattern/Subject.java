package Implemented_Using_ChainPattern;

interface Subject {
	public void setNextSubject(Subject subject);
	public void hasPassMark(Candidate numbers, RequiredPassMark required);
}
