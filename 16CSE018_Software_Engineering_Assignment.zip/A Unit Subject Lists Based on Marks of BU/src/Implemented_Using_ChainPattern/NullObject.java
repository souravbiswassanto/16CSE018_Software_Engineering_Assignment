package Implemented_Using_ChainPattern;
/*
 * code @uthor : Sourav Chandra Biswas
 * CSE - 4th BATCh
 * 16CSE-018
 */
public class NullObject implements Subject{
	private Subject nextSubject;
	public void setNextSubject(Subject subject) {
		this.nextSubject = subject;
	}
	public void hasPassMark(Candidate numbers, RequiredPassMark required) {
		System.out.println("No other subjects are selected");
	}

}
