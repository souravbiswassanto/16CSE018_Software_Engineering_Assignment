package Implemented_Using_ChainPattern;
import java.util.Scanner;
/*
 * code @uthor : Sourav Chandra Biswas
 * CSE - 4th BATCh
 * 16CSE-018
 */
public class Main {
	public static void main(String[] args) {
		//Setting required pass mark
		RequiredPassMark required = new RequiredPassMark();
		// marks of candidate
		Candidate examinee = new Candidate();
		int phy, bio, chem, math;
		Scanner input = new Scanner(System.in);
		System.out.println("Enter Physics Marks: ");
		phy = input.nextInt();
		System.out.println("Enter Biology Marks: ");
		bio = input.nextInt();
		System.out.println("Enter Mathematics Marks: ");
		math = input.nextInt();
		System.out.println("Enter Chemistry Marks: ");
		chem = input.nextInt();
		examinee.setValue(phy, bio, math, chem);
		examinee.set();
		
		Subject biochemistry = new Biochemistry();
		Subject botany = new Botany();
		Subject chemistry = new Chemistry();
		Subject cse = new CSE();
		Subject geology = new Geology();
		Subject mathematics = new Mathematics();
		Subject physics = new Physics();
		Subject soil = new Soil();
		Subject statistics = new Statistics();
		Subject nulobj = new NullObject();
		
		System.out.println("Selected subject List : ");
		
		biochemistry.setNextSubject(botany);
		botany.setNextSubject(chemistry);
		chemistry.setNextSubject(cse);
		cse.setNextSubject(geology);
		geology.setNextSubject(mathematics);
		mathematics.setNextSubject(physics);
		physics.setNextSubject(soil);
		soil.setNextSubject(statistics);
		statistics.setNextSubject(nulobj);
		
		biochemistry.hasPassMark(examinee, required);
	}
}
