package Implemented_Using_ChainPattern;
/*
 * code @uthor : Sourav Chandra Biswas
 * CSE - 4th BATCh
 * 16CSE-018
 */
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.Scanner;

public class RequiredPassMark {
	Scanner input = new Scanner(System.in);
	Hashtable<String,Integer> marks = new Hashtable<String, Integer>();
	Map<String, Map<String, Integer>> map = new HashMap<>();
	
	void print() {
		System.out.println("--^---------------^--");
	}
	String[] sub = {"physics", "chemistry", "biology", "mathematics"};
	String[] subjects = {"Biochemistry", "Botany", "Chemistry", "CSE", "Geology", "Mathematics","Physics","Soil", "Statistics"};
	ArrayList<ArrayList<Integer>> list = new ArrayList<>(9);
	ArrayList<ArrayList<Integer>> mark = new ArrayList<>(9);
	RequiredPassMark(){
		
		for(int i = 0; i < 9; i++) {
			list.add(new ArrayList());
			mark.add(new ArrayList());
		}
		list.get(0).add(1); mark.get(0).add(5); list.get(0).add(2); mark.get(0).add(8);
		list.get(1).add(2); mark.get(1).add(7);
		list.get(2).add(1); mark.get(2).add(5);
		list.get(3).add(0); mark.get(3).add(8); list.get(3).add(3); mark.get(3).add(8);
		list.get(4).add(0); mark.get(4).add(7);
		list.get(5).add(3); mark.get(5).add(10);
		list.get(6).add(0); mark.get(6).add(8);
		list.get(7).add(1); mark.get(7).add(6);
		list.get(8).add(3); mark.get(8).add(6);
		for(int i = 0; i < 9; i++) {
			print();
			System.out.println("Dependecies for subject -> " + subjects[i]);
			Map<String, Integer> m = new HashMap<>();
			for(int j = 0; j < list.get(i).size(); j++) {
				int a = list.get(i).get(j);
				String s = sub[a];
				int marks = mark.get(i).get(j);
				System.out.println("Subject = " + sub[a] + " Mark required = " + mark.get(i).get(j));
				m.put(s, marks);
			}
			map.put(subjects[i], m);
			print();
			System.out.println();
		}

	}
	
}
