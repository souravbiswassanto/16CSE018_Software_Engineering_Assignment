package Implemented_Using_ChainPattern;
import java.util.Hashtable; // for mapping values
public class Candidate {
	Hashtable<String,Integer> marks = new Hashtable<String, Integer>();
	// this is used to map string and integer. i e to assign pass marks for
	// each subjects.
	// constructor
	int physics, biology, mathematics, chemistry;
	void setValue(int phy, int bio, int math, int chem) {
		this.physics = phy;
		this.biology = bio;
		this.mathematics = math;
		this.chemistry = chem;
	}
	void set() {
		marks.put("physics", physics);
		marks.put("biology", biology);
		marks.put("mathematics", mathematics);
		marks.put("chemistry", chemistry);
	}
	Candidate(){
		//taking input from users
		// setting mapped value.
	}
}
