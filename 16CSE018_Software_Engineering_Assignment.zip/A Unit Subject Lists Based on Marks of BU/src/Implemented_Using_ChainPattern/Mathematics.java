package Implemented_Using_ChainPattern;
/*
 * code @uthor : Sourav Chandra Biswas
 * CSE - 4th BATCh
 * 16CSE-018
 */
import java.util.HashMap;
import java.util.Map;

public class Mathematics implements Subject{
	private Subject nextSubject;
	String name = "Mathematics";
	Map<String, Integer> map = new HashMap<>();
	public void setNextSubject(Subject subject) {
		this.nextSubject = subject;
	}
	public void hasPassMark(Candidate numbers, RequiredPassMark required) {
		map = required.map.get(name); boolean check = true;
		for(Map.Entry<String, Integer> data : map.entrySet() ) {
			String sub = data.getKey();
			int mark = data.getValue();
			if(numbers.marks.get(sub) < mark){
				check = false;
			}
		}
		if(check == true) {
			System.out.println("Mathematics");
		}
		nextSubject.hasPassMark(numbers, required);
	}
}
